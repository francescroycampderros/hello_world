docker cp hello_world.zip ubuntu_fra:/
mv /hello_world.zip /var/www/francescroy.com/modules/custom/
rm -rf hello_world
unzip hello_world.zip
php /var/www/francescroy.com/vendor/bin/drush.php un hello_world
php /var/www/francescroy.com/vendor/bin/drush.php en hello_world
php /var/www/francescroy.com/vendor/bin/drush.php cache-rebuild